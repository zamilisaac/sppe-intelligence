# Website files go here

Unzip `sppe-intelligence-cloudflare.zip` (the latest Cloudflare build, 39 files) into this folder so it contains:

```
website/
  index.html
  data/snapshot.json
  lib/            (SheetJS, jsPDF)
  reports/        (34 productivity PDFs, BM + EN)
```

Then delete this README (or keep it) and commit.
