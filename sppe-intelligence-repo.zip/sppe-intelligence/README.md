# SPPE Intelligence

**Analitik Ekonomi & Produktiviti Negeri · State Economic & Productivity Analytics**

A bilingual (Bahasa Melayu / English) website that turns official DOSM statistics into state-level economic intelligence for Malaysia: maps, rankings, 10-year timelines, and consultant-style reports. Built for the Malaysia Productivity Corporation (Perbadanan Produktiviti Malaysia, MPC).

## What the site does

| Page | Content |
|---|---|
| Home | Headline tiles, metric switch, playable map + state ranking race, state trend vs Malaysia, topic cards |
| Labour Productivity | Original productivity dashboard: map, ranking race, performance matrix, sector view |
| GDP & Economic Structure | GDP, growth, sector shares, specialisation index |
| Salaries & Wages | Survey median/mean wages, formal-sector wages, real wages |
| Labour Market | Participation, unemployment, female participation, employment |
| Integrated Economic Intelligence | Productivity-wage quadrant, scorecards, sector opportunity screen |
| Reports | Smart Report Builder: generates editable Word (.docx) reports by topic, full, or custom |

## Repository layout

```
website/   Static site, ready for Cloudflare Pages (index.html, data/, lib/, reports/)
data/dosm/ Source datasets from DOSM (OpenDOSM), 16 CSV files
docs/      Build notes, data inventory, methodology and design decisions
assets/    MPC logo
```

## Run locally

The site loads `data/snapshot.json` with `fetch`, so it must be served over HTTP (double-clicking `index.html` will not load the data):

```bash
cd website
python -m http.server 8000
# open http://localhost:8000
```

## Deploy to Cloudflare Pages

1. In Cloudflare, go to **Workers & Pages → Create → Pages → Connect to Git** and pick this repository.
2. Framework preset: **None**. Build command: *(leave empty)*. Build output directory: `website`.
3. Save and deploy. Every push to `main` redeploys the site.

## Updating the data

The static site does not auto-update from Google Drive. When DOSM publishes new figures, regenerate `website/data/snapshot.json` (and `website/reports/` for the productivity PDFs), commit, and push. See `docs/cloudflare-static-export.md`.

## Data sources and attribution

All statistics come from the **Department of Statistics Malaysia (DOSM)**, via OpenDOSM (https://open.dosm.gov.my). Calculations are by SPPE Intelligence. See `data/README.md` for each dataset and `docs/module06-data-inventory.md` for coverage and known gaps. Values that are not available in the official data are reported as not available and never estimated.

The MPC logo is the property of Perbadanan Produktiviti Malaysia.
